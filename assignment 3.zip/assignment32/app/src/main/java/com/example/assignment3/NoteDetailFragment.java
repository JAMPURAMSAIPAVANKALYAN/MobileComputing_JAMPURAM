package com.example.assignment3;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

public class NoteDetailFragment extends Fragment {
    private TextView noteTitleTextView;
    private TextView noteContentTextView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_note_detail, container, false);
        noteTitleTextView = view.findViewById(R.id.noteTitleTextView);
        noteContentTextView = view.findViewById(R.id.noteContentTextView);
        return view;
    }

    public void setNoteContent(String title, String content) {
        noteTitleTextView.setText(title);
        noteContentTextView.setText(content);
    }
}
