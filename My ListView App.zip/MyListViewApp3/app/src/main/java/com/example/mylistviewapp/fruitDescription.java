package com.example.mylistviewapp;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.view.WindowCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.mylistviewapp.databinding.ActivityFruitDescriptionBinding;

public class fruitDescription extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fruit_description);
        Intent intent=getIntent();

        String fruitname = intent.getStringExtra("fruitName");
        TextView name=(TextView) findViewById(R.id.detailFruitName);
       // Log.d("TAG", fruitname);
        name.setText(fruitname);

        int fruitimage = intent.getIntExtra("fruitImage",1);
        ImageView image=(ImageView)  findViewById(R.id.detailFruitImage);
        // Log.d("TAG", fruitImage);
        image.setImageResource(fruitimage);

        String fruitdescription = intent.getStringExtra("fruitDescription");
        TextView description=(TextView) findViewById(R.id.detailFruitDescription);
        // Log.d("TAG", fruitDescription);
        description.setText(fruitdescription);




    }

}
