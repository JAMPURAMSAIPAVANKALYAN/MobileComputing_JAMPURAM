package com.example.assignment3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import java.io.FileOutputStream;
import java.io.IOException;

public class AddNoteActivity extends AppCompatActivity {
    private EditText noteTitleEditText;
    private EditText noteContentEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_note);

        noteTitleEditText = findViewById(R.id.noteTitleEditText);
        noteContentEditText = findViewById(R.id.noteContentEditText);

        Button saveNoteButton = findViewById(R.id.saveNoteButton);
        Button cancelButton = findViewById(R.id.cancelButton);

        saveNoteButton.setOnClickListener(v -> {

            String noteTitle = noteTitleEditText.getText().toString();
            String noteContent = noteContentEditText.getText().toString();

            saveNoteToFile(noteTitle, noteContent);
            Intent intent = new Intent();
            intent.putExtra("noteTitle", noteTitle);
            setResult(RESULT_OK, intent);
            finish();
        });

        cancelButton.setOnClickListener(v -> {
            setResult(RESULT_CANCELED);
            finish();
        });
    }

    private void saveNoteToFile(String noteTitle, String noteContent) {
        try {
            FileOutputStream fos = openFileOutput("notes.txt", MODE_APPEND);
            String noteData = noteTitle + "\n" + noteContent + "\n";
            fos.write(noteData.getBytes());
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}