package com.example.assignment3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private List<String> noteTitles = new ArrayList<>();
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView noteListView = findViewById(R.id.noteListView);
        Button addNoteButton = findViewById(R.id.addNoteButton);
        noteTitles = loadNoteTitlesFromStorage();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, noteTitles);
        noteListView.setAdapter(adapter);

        noteListView.setOnItemClickListener((parent, view, position, id) -> {
        });

        addNoteButton.setOnClickListener(view -> {
            Intent intent = new Intent(this, com.example.assignment3.AddNoteActivity.class);
            startActivityForResult(intent, 1);
        });
    }
    private List<String> loadNoteTitlesFromStorage() {
        List<String> titles = new ArrayList<>();
        try {
            FileInputStream fis = openFileInput("notes.txt");
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            String line;
            while ((line = br.readLine()) != null) {
                titles.add(line);
            }
            fis.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return titles;
    }

    private void addNoteTitle(String title) {
        noteTitles.add(title);
        adapter.notifyDataSetChanged();
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                String newNoteTitle = data.getStringExtra("noteTitle");
                addNoteTitle(newNoteTitle);
            }
        }
    }


}