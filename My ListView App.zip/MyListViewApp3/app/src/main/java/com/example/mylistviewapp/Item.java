package com.example.mylistviewapp;

public class Item {
    String fruitName;
    int fruitImage;
    String fruitDescription;

    public Item(String fruitName, int fruitImage, String fruitDescription) {
        this.fruitImage = fruitImage;
        this.fruitName = fruitName;
        this.fruitDescription = fruitDescription;
    }

    public String getfruitName() {
        return fruitName;
    }

    public int getfruitImage() {
        return fruitImage;
    }

    public String getfruitDescription() {
        return fruitDescription;
    }

    public String getfruitImageResId() {
        return null;
    }
}