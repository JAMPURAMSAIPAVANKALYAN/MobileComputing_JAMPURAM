package com.example.mylistviewapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.os.Bundle;
import android.util.EventLogTags;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.content.Intent;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView simpleList;
    ArrayList<Item> fruitList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        simpleList = (ListView) findViewById(R.id.simpleListView);
        fruitList.add(new Item("Apple", R.drawable.apple, "Description: Apples are a popular fruit known for their sweet and crisp taste. They come in a variety of colors, including red, green, and yellow. Apples are not only delicious but also nutritious, making them a healthy choice for a snack or addition to your meals."));
        fruitList.add(new Item("Banana", R.drawable.banana, "Description: Bananas are a popular tropical fruit known for their deliciously sweet flavor and distinctive yellow color. They are a great source of essential nutrients, including potassium, vitamin C, and vitamin B6.  They are known for their convenience, as they come in their own natural packaging—peel and eat!"));
        fruitList.add(new Item("Avacado", R.drawable.avacado , "Avocados or “alligator pears” are known for their creamy smooth flesh and bumpy skin. They are a popular food across many cultures. Perhaps best known as the star ingredient in guacamole, they are versatile and prepared in an array of dishes, or simply eaten plain with a spoon. Although not sweet, avocados are botanically classified as a fruit with a large berry and single center pit, grown from the Persea americana tree. They are believed to have originated in Mexico or Central America, with Mexico being the leading producer worldwide."));
        fruitList.add(new Item("Dragon fruit", R.drawable.dragonfruit, "Description: Dragon fruit is a tropical fruit that’s low in calories and high in fiber and antioxidants. Some people say it tastes like a cross between a pear and a kiwi. You can slice and eat the fruit as-is, try it with yogurt, or add it to a smoothie or salad.Dragon fruit contains several antioxidants that protect your cells from damage. These include betalains, hydroxycinnamates, and flavonoids."));
        fruitList.add(new Item("Grapes", R.drawable.grapes, "Description: Grapes are small, round, and usually purple or green in color. They are a popular fruit known for their sweet and juicy taste. Grapes are not only delicious but also nutritious, containing vitamins, minerals, and antioxidants. They can be eaten fresh or used to make various products, including wine, raisins, and grape juice. "));
        fruitList.add(new Item("Guava", R.drawable.guava, "Description: Guava is a tropical fruit known for its sweet and slightly tangy flavor. It's rich in essential nutrients, including vitamin C, vitamin A, and dietary fiber, making it a healthy addition to your diet. Guavas are often enjoyed fresh or used in various culinary applications, such as juices, jams, and desserts. They are also recognized for their potential health benefits. "));
        fruitList.add(new Item("Kiwi", R.drawable.kiwi, "Description: Kiwi fruit, also known as the Chinese gooseberry, is a small, vibrant green fruit with tiny black seeds and fuzzy brown skin. This exotic fruit is renowned for its sweet and tangy flavor, often described as a delightful blend of tropical and citrus notes. Kiwis are not only delicious but also incredibly nutritious, packed with vitamins, minerals, and dietary fiber."));
        fruitList.add(new Item("Mango", R.drawable.mango, "Description: Mango, often referred to as the \"king of fruits,\" is a luscious tropical fruit cherished for its sweet and exotic flavor. With its vibrant orange-yellow flesh and a unique blend of sweetness and tanginess, mangoes are not only delicious but also rich in essential vitamins and minerals. "));
        fruitList.add(new Item("BlueBErries", R.drawable.blueberries, "Description: Blueberries are often called a “superfood.” This small but mighty berry is loaded with nutrients . They may help lower blood pressure, prevent heart disease, improve memory, aid in exercise recovery, and more."));
        fruitList.add(new Item("Papaya", R.drawable.papaya, "Description:Papaya is a tropical fruit known for its vibrant orange flesh and sweet flavor. It is rich in essential nutrients, particularly vitamin C and vitamin A, which contribute to its reputation as a superfood. Papaya is not only delicious but also offers numerous health benefits. Its enzymes, such as papain, aid in digestion and can alleviate digestive issues."));
        fruitList.add(new Item("Pineapple", R.drawable.pineapple, "Description: Pineapple is a tropical fruit renowned for its sweet and tangy flavor. With its distinctive spiky exterior and vibrant golden-yellow flesh, pineapple is a delightful tropical treat. This fruit is not only delicious but also nutritious, as it is a rich source . Pineapples can be enjoyed fresh, juiced, or used in various culinary dishes, adding a burst of tropical sweetness to salads, desserts, and savory dishes. "));
        fruitList.add(new Item("Starfruit", R.drawable.starfruit, "Description: \n" +
                "Star fruit is a sweet and sour fruit that has the shape of a five-point star. The skin is edible and the flesh has a mild, sour flavor that makes it popular in a number of dishes. The star fruit is yellow or green in color. It comes in two main types: a smaller, sour variety and a larger, sweeter one."));
        fruitList.add(new Item("Watermelon", R.drawable.watermelon, "Description: Watermelon is a refreshing and hydrating fruit known for its sweet, juicy taste and vibrant pink or red flesh. It's not only delicious but also incredibly hydrating, consisting of over 90% water, making it a perfect choice for staying hydrated during hot summer days. This fruit is low in calories and packed with essential vitamins and minerals, including vitamin C, vitamin A, and potassium."));
        MyAdapter myAdapter = new MyAdapter(this, R.layout.list_view_items, fruitList);

        simpleList.setAdapter(myAdapter);
        simpleList.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent,
                                    View view, int position, long id) {
                Item item = (Item)simpleList.getItemAtPosition(position);
                Toast.makeText(getBaseContext(), item.getfruitName(),
                        Toast.LENGTH_LONG).show();
                try {
                    Intent intent = new Intent(MainActivity.this, fruitDescription.class);
                    intent.putExtra("fruitName", item.getfruitName());
                    intent.putExtra("fruitDescription", item.getfruitDescription());
                    intent.putExtra("fruitImage", item.getfruitImage());
                    intent.putExtra("fruitImageResid", item.getfruitImageResId());
                    startActivity(intent);
                }catch (Exception e ){/* Log error messages */}
            }
        }); //end of setOnClickListener()
    } // end of onCreate()
} // end of class MainActivity

